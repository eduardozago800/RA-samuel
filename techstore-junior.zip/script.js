/* ================================================================
   TechStore Júnior - script.js
   Aqui ficam os produtos, o carrinho, os cálculos e as validações.
   ================================================================ */

/* ===== PRODUTOS DA LOJA (RF02) ===== */
let produtos = [
  {
    id: 1,
    nome: "Fone de Ouvido Bluetooth",
    descricao: "Fone sem fio com microfone.",
    preco: 249.90,
    imagem: "imagens/fone-bluetooth.svg"
  },
  {
    id: 2,
    nome: "Carregador Turbo USB-C",
    descricao: "Carregamento rápido com cabo USB tipo C",
    preco: 89.90,
    imagem: "imagens/carregador-turbo.svg"
  },
  {
    id: 3,
    nome: "Mouse Sem Fio",
    descricao: "Mouse óptico sem fio.",
    preco: 129.90,
    imagem: "imagens/mouse-sem-fio.svg"
  }
];

/* ===== CARRINHO (começa vazio) ===== */
let carrinho = [];

/* ===== FUNÇÃO PARA MOSTRAR O PREÇO EM REAIS ===== */
function formatarMoeda(valor) {
  return "R$ " + valor.toFixed(2).replace(".", ",");
}

/* ===== MOSTRAR OS PRODUTOS NA TELA (RF02) ===== */
function mostrarProdutos() {
  let caixa = document.getElementById("lista-produtos");
  let texto = "";

  for (let i = 0; i < produtos.length; i++) {
    let p = produtos[i];

    texto += "<article class='card-produto'>";
    texto += "<img src='" + p.imagem + "' alt='" + p.nome + "'>";
    texto += "<h3>" + p.nome + "</h3>";
    texto += "<p>" + p.descricao + "</p>";
    texto += "<p class='preco'>" + formatarMoeda(p.preco) + "</p>";
    texto += "<button onclick='adicionarAoCarrinho(" + p.id + ")'>Adicionar ao carrinho</button>";
    texto += "</article>";
  }

  caixa.innerHTML = texto;
}

/* ===== ADICIONAR UM PRODUTO AO CARRINHO (RF03) ===== */
function adicionarAoCarrinho(id) {
  // procura o produto na lista de produtos
  let produto = null;
  for (let i = 0; i < produtos.length; i++) {
    if (produtos[i].id === id) {
      produto = produtos[i];
    }
  }

  // procura o produto dentro do carrinho
  let posicao = -1;
  for (let i = 0; i < carrinho.length; i++) {
    if (carrinho[i].id === id) {
      posicao = i;
    }
  }

  // se já existe no carrinho, só aumenta a quantidade
  if (posicao === -1) {
    carrinho.push({
      id: produto.id,
      nome: produto.nome,
      preco: produto.preco,
      quantidade: 1
    });
  } else {
    carrinho[posicao].quantidade = carrinho[posicao].quantidade + 1;
  }

  atualizarCarrinho();
}

/* ===== REMOVER UM PRODUTO DO CARRINHO (RF03) ===== */
function removerDoCarrinho(id) {
  for (let i = 0; i < carrinho.length; i++) {
    if (carrinho[i].id === id) {
      carrinho.splice(i, 1);
    }
  }

  atualizarCarrinho();
}

/* ===== CALCULAR O SUBTOTAL (RF04) ===== */
function calcularSubtotal() {
  let subtotal = 0;

  for (let i = 0; i < carrinho.length; i++) {
    subtotal = subtotal + (carrinho[i].preco * carrinho[i].quantidade);
  }

  return subtotal;
}

/* ===== CALCULAR O DESCONTO (RN01) ===== */
function calcularDesconto(subtotal) {
  // compras ACIMA de R$ 200,00 ganham 10% de desconto
  if (subtotal > 200) {
    return subtotal * 0.10;
  } else {
    return 0;
  }
}

/* ===== CALCULAR O TOTAL FINAL (RF04) ===== */
function calcularTotal(subtotal, desconto) {
  return subtotal - desconto;
}

/* ===== MOSTRAR O CARRINHO E OS VALORES NA TELA (RF03 e RF04) ===== */
function atualizarCarrinho() {
  let lista = document.getElementById("lista-carrinho");
  let texto = "";
  let quantidadeTotal = 0;

  if (carrinho.length === 0) {
    texto = "<p class='vazio'>Seu carrinho está vazio. Clique em um produto para adicionar.</p>";
  } else {
    for (let i = 0; i < carrinho.length; i++) {
      let item = carrinho[i];
      quantidadeTotal = quantidadeTotal + item.quantidade;

      texto += "<div class='item-carrinho'>";
      texto += "<p>" + item.nome + " (" + item.quantidade + "x) = " +
        formatarMoeda(item.preco * item.quantidade) + "</p>";
      texto += "<button onclick='removerDoCarrinho(" + item.id + ")'>Remover</button>";
      texto += "</div>";
    }
  }

  lista.innerHTML = texto;

  // resumo no cabeçalho (if/else para o plural)
  if (quantidadeTotal === 1) {
    document.getElementById("resumo-carrinho").innerHTML = "Carrinho: 1 item";
  } else {
    document.getElementById("resumo-carrinho").innerHTML = "Carrinho: " + quantidadeTotal + " itens";
  }

  // cálculos do subtotal, desconto e total
  let subtotal = calcularSubtotal();
  let desconto = calcularDesconto(subtotal);
  let total = calcularTotal(subtotal, desconto);

  document.getElementById("subtotal").innerHTML = formatarMoeda(subtotal);
  document.getElementById("desconto").innerHTML = formatarMoeda(desconto);
  document.getElementById("total").innerHTML = formatarMoeda(total);

  // mostra a linha do desconto somente quando existe desconto
  let linhaDesconto = document.getElementById("linha-desconto");
  if (desconto > 0) {
    linhaDesconto.className = "";
  } else {
    linhaDesconto.className = "oculto";
  }
}

/* ===== MOSTRAR UMA MENSAGEM NA TELA ===== */
function mostrarMensagem(texto, tipo) {
  let mensagem = document.getElementById("mensagem");
  mensagem.innerHTML = texto;
  mensagem.className = tipo;
}

/* ===== VALIDAR O FORMULÁRIO DE FINALIZAÇÃO (RF05, RN02, RN03 e RN04) ===== */
function validarFormulario(evento) {
  evento.preventDefault(); // impede que a página recarregue

  let nome = document.getElementById("nome").value;
  let email = document.getElementById("email").value;
  let quantidade = document.getElementById("quantidade").value;

  // nenhum produto no carrinho
  if (carrinho.length === 0) {
    mostrarMensagem("Adicione pelo menos um produto ao carrinho antes de finalizar.", "erro");
    return false;
  }

  // RN02 - o nome precisa ter no mínimo 3 caracteres
  if (nome.length < 3) {
    mostrarMensagem("Erro no nome: digite pelo menos 3 caracteres.", "erro");
    return false;
  }

  // RN03 - o e-mail precisa ter "@" e "."
  if (email.indexOf("@") === -1) {
    mostrarMensagem("Erro no e-mail: o e-mail precisa ter o caractere @.", "erro");
    return false;
  } else if (email.indexOf(".") === -1) {
    mostrarMensagem("Erro no e-mail: o e-mail precisa ter um ponto (exemplo@email.com).", "erro");
    return false;
  }

  // RN04 - a quantidade precisa ser um número inteiro maior que zero
  if (quantidade === "") {
    mostrarMensagem("Erro na quantidade: preencha a quantidade de itens.", "erro");
    return false;
  } else if (Number(quantidade) <= 0) {
    mostrarMensagem("Erro na quantidade: digite um número maior que zero.", "erro");
    return false;
  } else if (Number(quantidade) !== parseInt(quantidade)) {
    mostrarMensagem("Erro na quantidade: use apenas números inteiros, sem vírgula.", "erro");
    return false;
  }

  // tudo certo: finalização simulada
  let total = calcularTotal(calcularSubtotal(), calcularDesconto(calcularSubtotal()));
  mostrarMensagem("Compra finalizada com sucesso, " + nome + "! Valor total: R$ " +
    total.toFixed(2).replace(".", ",") + " (pagamento simulado).", "sucesso");

  // limpa o formulário e o carrinho
  document.getElementById("form-compra").reset();
  carrinho = [];
  atualizarCarrinho();

  return false;
}

/* ===== INÍCIO DO PROGRAMA ===== */
mostrarProdutos();
atualizarCarrinho();
